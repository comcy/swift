//
//  input_bridge.c
//  BubbleSort_Bridged
//
//  Created by Silfang, Christian on 27.10.14.
//  Copyright (c) 2014 Silfang, Christian. All rights reserved.
//

#include "input_bridge.h"

void getInput(int *output)
{
    printf("-> ");
    scanf("%i", output);
}