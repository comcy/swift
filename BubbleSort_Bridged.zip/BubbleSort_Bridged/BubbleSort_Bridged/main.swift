//
//  main.swift
//  BubbleSort_Bridged
//
//  Created by Silfang, Christian on 27.10.14.
//  Copyright (c) 2014 Silfang, Christian. All rights reserved.
//

import Foundation

var c:Int32 = 0
var arrDesc:[Int32] = []
var arrAsc:[Int32] = []
var sort:Int32 = 0;

// Anzahl der Zahlen einlesen4
println("# Eingaben #")
println("Anzahl der zu sortierenden Zahlen eingeben")
getInput(&c)

// Zahlen einlesen
println("Anzahl der zu sortierenden Zahlen eingeben: \(c)")

for var i:Int32 = 0; i < c; i++ {
    var input:Int32 = 0
    print("Zahl \(i+1): ")
    getInput(&input)
    arrDesc.append(input) // Eingaben in Array speichern
    arrAsc.append(input)
}

// Absteigende Sortierung
var desc:Int32 = 0
for var loop = 0; loop < 100; loop++ {
    for var b = 0; b < arrDesc.count-1; b++ {
        if( arrDesc[b] < arrDesc[b+1]) { // Sortierung absteigend
            desc = arrDesc[b]
            arrDesc[b] = arrDesc[b+1]
            arrDesc[b+1] = desc
        }
    }
}

// Aufsteigende Sortierung
var asc:Int32 = 0
for var loop = 0; loop < 100; loop++ {
    for var b = 0; b < arrAsc.count-1; b++ {
        
        if( arrAsc[b] > arrAsc[b+1]) { // Sortierung aufsteigend
            asc = arrAsc[b]
            arrAsc[b] = arrAsc[b+1]
            arrAsc[b+1] = asc
        }
    }
}

// Ausgabe der Sortierung
println("# Sortierung #")
println("Absteigend: \(arrDesc) ")
println("Aufsteigend: \(arrAsc) ")