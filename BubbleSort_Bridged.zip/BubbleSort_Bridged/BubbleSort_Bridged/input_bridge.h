//
//  input_bridge.h
//  BubbleSort_Bridged
//
//  Created by Silfang, Christian on 27.10.14.
//  Copyright (c) 2014 Silfang, Christian. All rights reserved.
//

#ifndef __BubbleSort_Bridged__input_bridge__
#define __BubbleSort_Bridged__input_bridge__

#include <stdio.h>

void getInput(int *output);

#endif /* defined(__BubbleSort_Bridged__input_bridge__) */
